package com.tcs.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import jdk.internal.org.xml.sax.SAXException;

public class ToXMLAndCSV {

	/**
	 * @param args
	 */
	BufferedReader in;
	StreamResult out;
	TransformerHandler th;
	
	
	public static void main(String[] args) {
		new ToXMLAndCSV().begin();

	}
	public void begin(){
		try{
			in=new BufferedReader(new FileReader("C:\\text\\data.txt"));
			out=new StreamResult("C:\\text\\data.xml");
			openXML();
			String str;
			while((str=in.readLine())!=null){
				process(str);
			}
			System.out.println(out);
			in.close();
			closeXML();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void closeXML() throws org.xml.sax.SAXException{
		th.endElement(null, null, "sentence");
		th.endDocument();
		
	}
	public void process(String s) throws org.xml.sax.SAXException{
		//th.startElement(null, null, "word", null);
		  StringTokenizer st = new StringTokenizer(s," "); 
		  while (st.hasMoreTokens()) { 
			  th.startElement(null, null, "word", null);
			  String str = st.nextToken();
			  th.characters(str.toCharArray(),0,str.length());  
			  th.endElement(null, null, "word");
		     }  
		//th.characters(s.toCharArray(), 0, s.length());
		//th.endElement(null, null, "word");
		
	}
	public void openXML() throws ParserConfigurationException,TransformerConfigurationException,SAXException, org.xml.sax.SAXException{
		SAXTransformerFactory tf=(SAXTransformerFactory)TransformerFactory.newInstance();
		th=tf.newTransformerHandler();
		
		//For XML OutPut
		Transformer serializer=th.getTransformer();
		serializer.setOutputProperty("{http://xml.apache.org/xslt}ident-amount", "4");
		serializer.setOutputProperty(OutputKeys.INDENT, "yes");
		
		th.setResult(out);
		th.startDocument();
		th.startElement(null, null, "sentence", null);
		
	}

}
